'use strict';

define({
  errorClass: 'error',
  requiredClass: 'js-required',
  dialogClass: 'js-dialog',
  dialogContentClass: 'js-dialog-content',
  dialogCloseClass: 'js-dialog-close',
  modalClass: 'js-modal-dialog',
  dialogActiveClass: 'dialog-active',
  modalActiveClass: 'modal-active',

  emailSelector: '#email',
  postcodeSelector: '#postcode',
  agreementSelector: '#agreement',
  phoneSelector: '#phone',
  isClientSelector: '#isClient',
  isClientOptionsSelector: '[name="is-client"]',
  formSelector: '#registrationForm',
  dialogInfoSelector: '#dialogInfo',
  dialogSuccessSelector: '#dialogSuccess'
});