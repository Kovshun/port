'use strict';

define(['jquery', 'inputmask', 'utils'], function ($, inputmask, utils) {
  var $form = $(utils.formSelector),
    $isClient = $(utils.isClientSelector),
    $phone = $(utils.phoneSelector);

  function initEvents() {
    $form.on('change', utils.isClientOptionsSelector, function () {
      $phone.prop('disabled', !$isClient.prop('checked') ? true : false);
    });
  };

  return {
    init: function () {
      $(utils.postcodeSelector).inputmask('99999');
      $isClient.prop('checked', true);

      initEvents();
    }
  }
});
