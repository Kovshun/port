'use strict';

define(['jquery', 'utils'], function ($, utils) {
  var fadeDuration = 250,
    $body = $('body');

  return {
    hide: function () {
      $('.' + utils.dialogClass).fadeOut(fadeDuration, function () {
        $('.' + utils.modalActiveClass).removeClass(utils.modalActiveClass);
        $('.' + utils.dialogContentClass).empty();
        $body.removeClass(utils.dialogActiveClass);
      });
    },

    show: function ($dialogContent) {
      $('.' + utils.dialogClass).fadeIn(fadeDuration);
      $('.' + utils.dialogContentClass).append($dialogContent.clone().show());
      $('.' + utils.modalClass).addClass(utils.modalActiveClass);
      $body.addClass(utils.dialogActiveClass);
    },

    initEvents: function () {
      var self = this;

      $(document).on('click', function (evt) {
        var $target = $(evt.target),
          $closeButton = $target.closest('.' + utils.dialogCloseClass),
          $modalDialog = $target.closest('.' + utils.modalClass);

        if ($target.is('[data-open]')) {
          evt.preventDefault();

          self.show($($target.attr('data-open')));
        }

        if ($target.hasClass(utils.dialogClass) || $closeButton.length) {
          self.hide();
        }
      });
    },

    init: function () {
      this.initEvents();
    }
  }
});
