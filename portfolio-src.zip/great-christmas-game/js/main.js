'use strict';

requirejs.config({
  baseUrl: './js',
  paths: {
    inputmask: '../bower_components/inputmask/dist/jquery.inputmask.bundle',
    jquery: '../bower_components/jquery/dist/jquery'
  },
  shim: {
    'inputmask' : {
      deps: ['jquery'],
      exports: 'inputmask'
    }
  }
});

define(['dialog', 'form', 'validator', 'utils'], function (dialog, form, validator, utils) {
  dialog.init();
  form.init();
  validator.init();

  dialog.show($(utils.dialogInfoSelector));
});
