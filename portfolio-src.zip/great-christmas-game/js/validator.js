'use strict';

define(['jquery', 'utils', 'dialog'], function ($, utils, dialog) {
  var $form = $(utils.formSelector),
    $requiredInput = $form.find('.' + utils.requiredClass),
    $isClient = $(utils.isClientSelector);

  function getInputValidationResult($target) {
    var value = $.trim($target.val());

    if ($target.is(utils.emailSelector)) {
      return !value.search(/^.+@.+\..+$/);
    }

    if ($target.is(utils.postcodeSelector)) {
      return !value.search(/^\d{5}$/);
    }

    if ($target.is(utils.agreementSelector)) {
      value = $target.is(':checked');
    }

    return value;
  };

  function isFormValid($form) {
    return !$form.find('.' + utils.errorClass).length;
  };

  function validate($form) {
    var deferr = $.Deferred();

    $requiredInput.each(function () {
      var $this = $(this);

      if ($this.attr('disabled')) {
        $this.removeClass(utils.errorClass);

        return;
      }

      !getInputValidationResult($this) && $this.addClass(utils.errorClass);
    });

    deferr.resolve();

    return deferr;
  };

  function initEvents() {
    $form.on('submit', function (evt) {
      evt.preventDefault();

      validate($form).done(function () {
        if (!$form.find('.' + utils.errorClass).length) {
          // Submit form
          dialog.show($(utils.dialogSuccessSelector));
        }
      });
    });

    $form.on('input change', '.' + utils.errorClass, function () {
      var $this = $(this);

      if (getInputValidationResult($this)) {
        $this.removeClass(utils.errorClass);
      }
    });
  };

  return {
    init: function () {
      initEvents();
    }
  }
});
