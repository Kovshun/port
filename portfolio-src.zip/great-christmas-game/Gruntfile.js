'use strict';

module.exports = function (grunt) {
  grunt.initConfig({
    dist: grunt.file.readJSON('package.json').dist,

    shell: {
      removeDist: {
        command: 'rd /s/q "<%= dist %>"'
      }
    },

    copy: {
      images: {
        files: [{
          expand: true,
          src: ['img/**'],
          dest: '<%= dist %>/'
        }]
      },

      bower_files: {
        files: [{
          expand: true,
          src: [
            'bower_components/inputmask/dist/jquery.inputmask.bundle.js',
            'bower_components/jquery/dist/jquery.js'
          ],
          dest: '<%= dist %>/'
        }]
      },

      requirejs: {
        files: [{
          expand: true,
          flatten: true,
          filter: 'isFile',
          cwd: 'bower_components/',
          src: ['requirejs/require.js'],
          dest: '<%= dist %>/js/libs/'
        }]
      },

      js: {
        files: [{
          expand: true,
          cwd: 'js/',
          src: ['**/*'],
          dest: '<%= dist %>/js/'
        }]
      }
    },

    htmlmin: {
      all: {
        options: {
          collapseWhitespace: true
        },

        files: [{
          expand: true,
          cwd: 'templates/',
          src: ['**/*.html'],
          dest: '<%= dist %>/'
        }]
      }
    },

    requirejs: {
      build: {
        options: {
          mainConfigFile: 'js/main.js',
          baseUrl: 'js/',
          name: 'main',
          out: '<%= dist %>/js/main.js'
        }
      }
    },

    dom_munger: {
      build: {
        options: {
          remove: '#livereload'
        },

        src: '<%= dist %>/index.html',
        dest: this.src
      }
    },

    less: {
      all: {
        files: {
          '<%= dist %>/css/styles.css': 'less/styles.less'
        }
      }
    },

    autoprefixer: {
      options: {
        browsers: ['> 1%', 'last 2 versions', 'ie 8', 'ie 9']
      },

      all: {
        src: '<%= dist %>/css/styles.css',
        dest: this.src
      },
    },

    cmq: {
      build: {
        files: {
          '<%= dist %>/css': ['<%= dist %>/css/styles.css']
        }
      }
    },

    cssmin: {
      build: {
        files: {
          '<%= dist %>/css/styles.css': ['<%= dist %>/css/styles.css']
        }
      }
    },

    imagemin: {
      dist: {
        options: {
          cache: false
        },

        files: [{
          expand: true,
          cwd: 'img/',
          src: ['**/*.{png,jpg}'],
          dest: '<%= dist %>/img/'
        }]
      }
    },

    uglify: {
      build: {
        files: {
          '<%= dist %>/js/libs/require.js': '<%= dist %>/js/libs/require.js',
          '<%= dist %>/js/main.js': '<%= dist %>/js/main.js'
        }
      }
    },

    watch: {
      configFiles: {
        files: ['Gruntfile.js'],
        options: {
          reload: true
        }
      },

      options: {
        livereload: true,
        nospawn: true
      },

      html: {
        files: ['templates/**/*.html'],
        tasks: ['newer:htmlmin']
      },

      styles: {
        files: ['less/**/*.less'], 
        tasks: ['less', 'autoprefixer']
      },

      copy: {
        files: ['img/**/*.{png,jpg}', 'js/**/*.js'],
        tasks: ['newer:copy']
      }
    }
  });

  grunt.loadNpmTasks('grunt-autoprefixer');
  grunt.loadNpmTasks('grunt-dom-munger');
  grunt.loadNpmTasks('grunt-combine-media-queries');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-htmlmin');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-imagemin');
  grunt.loadNpmTasks('grunt-contrib-requirejs');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-newer');
  grunt.loadNpmTasks('grunt-shell');

  grunt.registerTask('default', ['copy', 'htmlmin', 'less', 'autoprefixer', 'watch']);
  grunt.registerTask('build', ['shell', 'copy:requirejs', 'htmlmin', 'dom_munger', 'less', 'autoprefixer', 'cmq', 'cssmin', 'requirejs', 'uglify', 'imagemin']);
};
