'use strict';

;(function ($) {
  var constants = require('./constants');

  require('./plugins/jquery.setParallax');

  require('./back-to-top').init();
  require('./dropdown').init();
  require('./navbar').init();

  $('#header').setParallax({
    bgElement: '#headerBackground'
  });

  matchMedia('screen and (max-width: ' + constants.mobileScreenWidth + 'px)').addListener(function () {
    $('#languages').slideUp(0);
  });

  // $('#carousel').slick({
  //   dots: true,
  //   infinite: false,
  //   slidesToShow: 1,
  //   slidesToScroll: 1
  // });
})(jQuery);
