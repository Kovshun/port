'use strict';

;(function ($) {
   $.fn.setParallax = function (options) {
    var $window = $(window),
      $target = this.first(),
      windowScrollTop,
      options;

    if ($(options.bgElement).length) {
      options = $.extend({
        speed: 1 / 3
      }, options);

      function Parallax(options) {
        var self = this;

        self.options = options;

        self.init();

        $window.on('resize scroll', function () {
          self.init.call(self);
        });
      };

      Parallax.prototype.init = function () {
        var options = this.options;

        windowScrollTop = $window.scrollTop();

        if (windowScrollTop < $target.height()) {
          $(options.bgElement).css({
            'bottom': -windowScrollTop * options.speed,
            'top': windowScrollTop * options.speed
          });
        }
      };

      new Parallax(options);
    }

    return this.first();
  };
})(jQuery);
