'use strict';

module.exports = {
  mobileScreenWidth: 640,

  classes: {
    backToTopBtn: 'js-back-to-top',
    dropdown: 'js-dropdown',
    dropdownMenu: 'js-dropdown-menu',
    activeMenu: 'active-menu',
    navbar: {
      active: 'active',
      hidden: 'hidden'
    }
  },

  selectors: {
    mainMenu: '#mainMenu',
    mainMenuContainer: '#mainMenuContainer',
    toggleMenuBtn: '#toggleMenuBtn'
  }
};
