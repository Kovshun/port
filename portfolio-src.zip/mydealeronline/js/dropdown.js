'use strict';

var constants = require('./constants'),
  classes = constants.classes,
  animationDuration = 500;

function toggleDropdown($dropdown) {
  $dropdown.find('.' + classes.dropdownMenu).slideToggle(animationDuration);
};

function hideDropdown(evt) {
  var $target = $(evt.target);

  if (!$target.closest('.' + classes.dropdown).length) {
    $('.' + classes.dropdownMenu).slideUp(animationDuration);
  }
};

function initEvents() {
  $(document).on('click', hideDropdown);

  $('.' + classes.dropdown).on('click', function () {
    toggleDropdown($(this));
  });
};

module.exports = {
  init: function () {
    initEvents();
  }
};
