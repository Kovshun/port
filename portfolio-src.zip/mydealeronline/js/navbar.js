'use strict';

var constants = require('./constants'),
  selectors = constants.selectors,
  classes = constants.classes,
  mediaQuery = matchMedia('screen and (min-width: ' + (constants.mobileScreenWidth + 1) + 'px)'),
  animationDuration = 500,
  $navbar = $(selectors.mainMenu),
  $navbarContainer = $(selectors.mainMenuContainer),
  $toggleMenuBtn = $(selectors.toggleMenuBtn),
  $body = $('body'),
  navbar = $navbar.get(0);

function hideNavbar(animationDuration) {
  navbar.className = navbar.className.replace(classes.navbar.active, classes.navbar.hidden);
  $navbarContainer.removeClass(classes.navbar.active);
  $toggleMenuBtn.removeClass(classes.navbar.active);
  $body.removeClass(classes.activeMenu);

  setTimeout(function () {
    $navbar.removeClass(classes.navbar.hidden);
  }, animationDuration);
};

function hideMobileNavbar() {
  mediaQuery.matches && hideNavbar(0);
};

function toggleNavbar() {
  $navbarContainer.toggleClass(classes.navbar.active);
  $body.toggleClass(classes.activeMenu);

  if ($navbar.hasClass(classes.navbar.active)) {
    navbar.className = navbar.className.replace(classes.navbar.active, classes.navbar.hidden);

    setTimeout(function () {
      $navbar.removeClass(classes.navbar.hidden);
    }, animationDuration);
  } else {
    $navbar.addClass(classes.navbar.active);
  }
};

function initEvents() {
  $navbar.on('click', function (evt) {
    if ($(evt.target).is($navbar)) {
      hideNavbar(animationDuration);
    }
  });

  $toggleMenuBtn.on('click', function () {
    $(this).toggleClass(classes.navbar.active);
    toggleNavbar();
  });

  mediaQuery.addListener(hideMobileNavbar);
};

module.exports = {
  init: function () {
    initEvents();
    hideMobileNavbar();
  }
};
