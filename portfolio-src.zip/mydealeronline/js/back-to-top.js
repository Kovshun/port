'use strict';

var $backToTopBtn = $('.js-back-to-top'),
  $root = $('html, body'),
  $window = $(window);

function toggleBtnVisibility() {
  if ($window.scrollTop() > $window.height()) {
    if ($backToTopBtn.is(':hidden')) {
      $backToTopBtn.fadeIn();
    }
  } else {
    if ($backToTopBtn.is(':visible')) {
      $backToTopBtn.fadeOut();
    }
  }
};

function animateScroll() {
  $root.animate({
    scrollTop: 0
  }, $window.scrollTop() / 2);
};

function initEvents() {
  $window.on('scroll', toggleBtnVisibility);
  $backToTopBtn.on('click', animateScroll);
};

module.exports = {
  init: function () {
    toggleBtnVisibility();
    initEvents();
  }
};
