﻿'use strict';

const gulp = require('gulp'),
  // utils
  browserSync = require('browser-sync').create(),
  buffer = require('vinyl-buffer'),
  isCase = require('gulp-if'),
  mainBowerFiles = require('main-bower-files'),
  merge = require('merge-stream'),
  rename = require("gulp-rename"),
  runSequence = require('run-sequence').use(gulp),
  source = require('vinyl-source-stream'),
  // styles
  autoprefixer = require('gulp-autoprefixer'),
  sass = require('gulp-sass'),
  sourcemaps = require('gulp-sourcemaps'),
  // HTML
  htmlmin = require('gulp-htmlmin'),
  htmlreplace = require('gulp-html-replace'),
  // JS
  browserify = require('browserify'),
  uglify = require('gulp-uglify'),
  // images
  imageResize = require('gulp-image-resize'),
  imagemin = require('gulp-imagemin'),
  spritesmith = require('gulp.spritesmith');

const dist = require('./package.json').dist,

  paths = {
    css: dist + '/css',
    scss: 'scss',
    templates: 'templates',
    js: {
      src: 'js',
      build: dist + '/js'
    },
    img: {
      src: 'img',
      icons: 'img/icons',
      sprites: 'img/sprites',
      build: dist + '/img'
    }
  },

  imgResizeConfig = {
    '/mobile-apps-bg.jpg': [{
      crop: true,
      width: 1024,
      upscale: false,
      suffix: '_1024'
    }, {
      crop: true,
      width: 640,
      upscale: false,
      suffix: '_640'
    }],

    '/header-bg.jpg': [{
      crop: true,
      width: 1024,
      upscale: false,
      suffix: '_1024'
    }, {
      crop: true,
      width: 640,
      upscale: false,
      suffix: '_640'
    }],
  },

  sprites = ['homepage', 'social-networks'];

let isBuild = false;


// Tasks

gulp.task('templates', () => {
  gulp.src(paths.templates + '/index.html', {
      dot: true
    })
    .pipe(isCase(isBuild, htmlreplace({
      'jquery': 'https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js'
    })))
    .pipe(htmlmin({
      collapseWhitespace: true,
      ignoreCustomFragments: [/<!--.*-->/]
    }))
    .pipe(gulp.dest(dist))
    .pipe(browserSync.stream());
});

gulp.task('bower-files', () => {
  if (!isBuild) {
    gulp.src(mainBowerFiles('**/*.js', {
        'overrides': {
          'jquery': {
            'main': [
              'dist/jquery.min.js'
            ]
          }
        }
      }))
      .pipe(gulp.dest(paths.js.build));
  }
});

gulp.task('img', () => {
  for (let img in imgResizeConfig) {
    imgResizeConfig[img].forEach((options) => {
      gulp.src(paths.img.src + img)
        .pipe(imageResize(options))
        .pipe(isCase(isBuild, imagemin()))
        .pipe(rename({
          suffix: options.suffix
        }))
        .pipe(gulp.dest(paths.img.build));
    });
  }

  gulp.src(['!' + paths.img.icons + '/**/*', paths.img.src + '/**/*'], {
      dot: true
    })
    .pipe(isCase(isBuild, imagemin()))
    .pipe(gulp.dest(paths.img.build))
    .pipe(browserSync.stream());
});

gulp.task('browserify', () => {
  browserify(paths.js.src + '/main.js')
    .transform('babelify', {
      presets: ['@babel/preset-env']
    })
    .bundle()
    .pipe(source('main.js'))
    .pipe(gulp.dest(paths.js.build))
    .pipe(browserSync.stream());
});

gulp.task('js-minify', () => {
  if (isBuild) {
    gulp.src(paths.js.build + '/main.js')
      .pipe(isCase(isBuild, uglify()))
      .pipe(gulp.dest(paths.js.build));
  }
});

gulp.task('scss', () => {
  gulp.src(paths.scss + '/**/*.scss')
    .pipe(isCase(!isBuild, sourcemaps.init()))
    .pipe(isCase(!isBuild, sass().on('error', sass.logError)))
    .pipe(isCase(!isBuild, sourcemaps.write()))
    .pipe(isCase(isBuild, sass({outputStyle: 'compressed'})))
    .pipe(autoprefixer({
      browsers: [
        'last 3 versions',
        '> 1%',
        'ie 9',
        'ie 8'
      ],
      cascade: false
    }))
    .pipe(gulp.dest(paths.css))
    .pipe(browserSync.stream());
});

sprites.forEach((spriteName) => {
  let taskName = 'sprite:' + spriteName;

  gulp.task(taskName, () => {
    let spriteData = gulp.src(paths.img.icons + '/' + spriteName + '/*').pipe(spritesmith({
      imgName: spriteName + '.png',
      imgPath: '../' + paths.img.sprites + '/' + spriteName + '.png',
      cssName: '_' + spriteName + '.scss',
      padding: 1
    }));

    let cssStream = spriteData.css.pipe(gulp.dest(paths.scss + '/sprites')),
      imgStream = spriteData.img
      .pipe(isCase(isBuild, buffer()))
      .pipe(isCase(isBuild, imagemin()))
      .pipe(gulp.dest(paths.img.build + '/sprites'));

    return merge(imgStream, cssStream);
  });
});

gulp.task('sprites', sprites.map((spriteName) => 'sprite:' + spriteName));

let runAll = () => runSequence(
  ['templates', 'bower-files', 'browserify', 'img', 'sprites'],
  ['scss', 'js-minify']
);

gulp.task('all', runAll);


// Development

gulp.task('default', ['all'], () => {
  browserSync.init({
    server: {
      baseDir: dist + '/'
    }
  });

  gulp.watch(paths.scss + '/**/*.scss', ['scss']);
  gulp.watch(paths.img.icons + '/**/*', () => runSequence('sprites', 'scss'));
  gulp.watch(['!' + paths.img.icons + '**/*', paths.img.src + '/**/*'], ['img']);
  gulp.watch(paths.js.src + '/**/*.js', ['js']);
  gulp.watch(paths.templates + '/**/*.html', ['templates']);
});


// Build

gulp.task('build', () => {
  isBuild = true;

  runAll();
});
